package com.tcs.subscriptionmicroservice.model;

public class Drugs {

}
